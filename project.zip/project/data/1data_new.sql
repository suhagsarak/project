
INSERT INTO address VALUES
(1,'Pune','India','ShaniwarWada','400001','Maharashtra','Fifth Avenue'),
(2,'Satara','India','PowaiNaka','400001','Maharashtra','Rajpath'),
(3,'Mumbai','India','Worli','400001','Maharashtra','Dalal Street'),
(4,'Jalgaon','India','Shiv Chowk','400001','Maharashtra','Rajpath'),
(5,'Sambhajinagar','India','nagar chowk','400001','Maharashtra','Shivaji Statue'),

(6,'Solapur','India','ShaniwarWada','400002','Maharashtra','Fifth Avenue'),
(7,'Yawatmal','India','PowaiNaka','400002','Maharashtra','Rajpath'),
(8,'Mumbai','India','Worli','400002','Maharashtra','Dalal Street'),
(9,'Jalgaon','India','Shiv Chowk','400002','Maharashtra','Rajpath'),
(10,'Sambhajinagar','India','nagar chowk','400002','Maharashtra','Shivaji Statue'),

(11,'Pune','India','ShaniwarWada','400003','Maharashtra','Fifth Avenue'),
(12,'Satara','India','PowaiNaka','400003','Maharashtra','Rajpath'),
(13,'Mumbai','India','Worli','400003','Maharashtra','Dalal Street'),
(14,'Jalgaon','India','Shiv Chowk','400003','Maharashtra','Rajpath'),
(15,'Sambhajinagar','India','nagar chowk','400003','Maharashtra','Shivaji Statue'),

(16,'Pune','India','ShaniwarWada','400004','Maharashtra','Fifth Avenue'),
(17,'Satara','India','PowaiNaka','400004','Maharashtra','Rajpath'),
(18,'Mumbai','India','Worli','400004','Maharashtra','Dalal Street'),
(19,'Jalgaon','India','Shiv Chowk','400004','Maharashtra','Rajpath'),
(20,'Sambhajinagar','India','nagar chowk','400004','Maharashtra','Shivaji Statue'),

(21,'Pune','India','ShaniwarWada','400005','Maharashtra','Fifth Avenue'),
(22,'Satara','India','PowaiNaka','400005','Maharashtra','Rajpath'),
(23,'Mumbai','India','Worli','400005','Maharashtra','Dalal Street'),
(24,'Jalgaon','India','Shiv Chowk','400005','Maharashtra','Rajpath'),
(25,'Sambhajinagar','India','nagar chowk','400005','Maharashtra','Shivaji Statue');



INSERT INTO center VALUES 
(1,'pitstop@gmail.com',             'Pitstop Car Services',             '+919970586815',10000,1),
(2,'omcars@gmail.com',             'Omcars Car Services',             '+918007665352',20000,2),
(3,'pashankarauto@gmail.com',             'Pashankarauto Car Services',             '+917487965748',23000,3),
(4,'swiftcars@gmail.com',             'Swiftcars Car Services',             '+917894587130',4000,4),
(5,'kalamauto@gmail.com',             'Kalamauto Car Services',             '+919157483690',50000,5),

(6,'marvellouscars@gmail.com',             'Marvellouscars Car Services',             '+919970586815',10000,6),
(7,'citymotors@gmail.com',             'Citymotors Car Services',             '+918007665352',20000,7),
(8,'carsurgeon@gmail.com',             'Carsurgeon Car Services',             '+917487965748',30000,8),
(9,'dynamiccars@gmail.com',             'Dynamiccars Car Services',             '+917894587130',40000,9),
(10,'kingauto@gmail.com',             'Kingauto Car Services',             '+919157483690',50000,10),

(11,'gomechanic@gmail.com',             'Gomechanic Car Services',             '+919970586815',10000,11),
(12,'platinumcars@gmail.com',             'Platinum Car Services',             '+918007665352',20000,12),
(13,'gscarzone@gmail.com',             'GS Car Services',             '+917487965748',30000,13),
(14,'axle9@gmail.com',             'Axle9 Car Services',             '+917894587130',40000,14),
(15,'laxmimatacars@gmail.com',             'Laxmimatacars Car Services',             '+919157483690',50000,15),

(16,'bavariamotors@gmail.com',             'Bavaria Car Services',             '+919970586815',10000,16),
(17,'audicarservices@gmail.com',             'Audicarservices Car Services',             '+918007665352',20000,17),
(18,'jainauto@gmail.com',             'Jainauto Car Services',             '+917487965748',30000,18),
(19,'kanasehyundai@gmail.com',             'Kanasehyundai Car Services',             '+917894587130',40000,19),
(20,'yashmotors@gmail.com',             'Yashmotors Car Services',             '+919157483690',50000,20),

(21,'fortunemotors@gmail.com',             'Fortune Car Services',             '+919970586815',10000,21),
(22,'machinepad@gmail.com',             'Machinepad Car Services',             '+918007665352',20000,22),
(23,'saharamotors@gmail.com',             'Saharamotors Car Services',             '+917487965748',30000,23),
(24,'foxcars@gmail.com',             'Foxcars Car Services',             '+917894587130',40000,24),
(25,'indiaauto@gmail.com',             'Indiaauto Car Services',             '+919157483690',50000,25);




INSERT INTO user VALUES 
(1,'pitstop@gmail.com',         'owner1234',    'OWNER'),
(2,'omcars@gmail.com',          'owner1234',    'OWNER'),
(3,'pashankarauto@gmail.com',   'owner1234',    'OWNER'),
(4,'swiftcars@gmail.com',       'owner1234',    'OWNER'),
(5,'kalamauto@gmail.com',       'owner1234',    'OWNER'),
(6,'marvellouscars@gmail.com',  'owner1234',    'OWNER'),
(7,'citymotors@gmail.com',      'owner1234',    'OWNER'),
(8,'carsurgeon@gmail.com',      'owner1234',    'OWNER'),
(9,'dynamiccars@gmail.com',     'owner1234',    'OWNER'),
(10,'kingauto@gmail.com',       'owner1234',    'OWNER'),
(11,'gomechanic@gmail.com',     'owner1234',    'OWNER'),
(12,'platinumcars@gmail.com',   'owner1234',    'OWNER'),
(13,'gscarzone@gmail.com',      'owner1234',    'OWNER'),
(14,'axle9@gmail.com',          'owner1234',    'OWNER'),
(15,'laxmimatacars@gmail.com',  'owner1234',    'OWNER'),
(16,'bavariamotors@gmail.com',  'owner1234',    'OWNER'),
(17,'audicarservices@gmail.com','owner1234',    'OWNER'),
(18,'jainauto@gmail.com',       'owner1234',    'OWNER'),
(19,'kanasehyundai@gmail.com',  'owner1234',    'OWNER'),
(20,'yashmotors@gmail.com',     'owner1234',    'OWNER'),
(21,'fortunemotors@gmail.com',  'owner1234',    'OWNER'),
(22,'machinepad@gmail.com',     'owner1234',    'OWNER'),
(23,'saharamotors@gmail.com',   'owner1234',    'OWNER'),
(24,'foxcars@gmail.com',        'owner1234',    'OWNER'),
(25,'indiaauto@gmail.com',      'owner1234',    'OWNER');



INSERT INTO owner VALUES 
(1,'pitstop@gmail.com',           'owner01',   'owner1234',    '+919970586815',    'OWNER',      1,    1   ),
(2,'omcars@gmail.com',            'owner02',   'owner1234',    '+918007665352',    'OWNER',      2,    2   ),
(3,'pashankarauto@gmail.com',     'owner03',   'owner1234',    '+917487965748',    'OWNER',      3,    3   ),
(4,'swiftcars@gmail.com',         'owner04',   'owner1234',    '+917894587130',    'OWNER',      4,    4   ),
(5,'kalamauto@gmail.com',         'owner05',   'owner1234',    '+919157483690',    'OWNER',      5,    5   ),
(6,'marvellouscars@gmail.com',    'owner06',   'owner1234',    '+919970586815',    'OWNER',      6,    6   ),
(7,'citymotors@gmail.com',        'owner07',   'owner1234',    '+918007665352',    'OWNER',      7,    7   ),
(8,'carsurgeon@gmail.com',        'owner08',   'owner1234',    '+917487965748',    'OWNER',      8,    8   ),
(9,'dynamiccars@gmail.com',       'owner09',   'owner1234',    '+917894587130',    'OWNER',      9,    9   ),
(10,'kingauto@gmail.com',         'owner10',   'owner1234',    '+919157483690',    'OWNER',     10,   10   ),
(11,'gomechanic@gmail.com',       'owner11',   'owner1234',    '+919970586815',    'OWNER',     11,   11   ),
(12,'platinumcars@gmail.com',     'owner12',   'owner1234',    '+918007665352',    'OWNER',     12,   12   ),
(13,'gscarzone@gmail.com',        'owner13',   'owner1234',    '+917487965748',    'OWNER',     13,   13   ),
(14,'axle9@gmail.com',            'owner14',   'owner1234',    '+917894587130',    'OWNER',     14,   14   ),
(15,'laxmimatacars@gmail.com',    'owner15',   'owner1234',    '+919157483690',    'OWNER',     15,   15   ),
(16,'bavariamotors@gmail.com',    'owner16',   'owner1234',    '+919970586815',    'OWNER',     16,   16   ),
(17,'audicarservices@gmail.com',  'owner17',   'owner1234',    '+918007665352',    'OWNER',     17,   17   ),
(18,'jainauto@gmail.com',         'owner18',   'owner1234',    '+917487965748',    'OWNER',     18,   18   ),
(19,'kanasehyundai@gmail.com',    'owner19',   'owner1234',    '+917894587130',    'OWNER',     19,   19   ),
(20,'yashmotors@gmail.com',       'owner20',   'owner1234',    '+919157483690',    'OWNER',     20,   20   ),
(21,'fortunemotors@gmail.com',    'owner21',   'owner1234',    '+919970586815',    'OWNER',     21,   21   ),
(22,'machinepad@gmail.com',       'owner22',   'owner1234',    '+918007665352',    'OWNER',     22,   22   ),
(23,'saharamotors@gmail.com',     'owner23',   'owner1234',    '+917487965748',    'OWNER',     23,   23   ),
(24,'foxcars@gmail.com',          'owner24',   'owner1234',    '+917894587130',    'OWNER',     24,   24   ),
(25,'indiaauto@gmail.com',        'owner25',   'owner1234',    '+919157483690',    'OWNER',     25,   25   );




INSERT INTO address VALUES
(26,'Pune','India','ShaniwarWada','400001','Maharashtra','Fifth Avenue'),
(27,'Satara','India','PowaiNaka','400001','Maharashtra','Rajpath'),
(28,'Mumbai','India','Worli','400002','Maharashtra','Dalal Street'),
(29,'Jalgaon','India','Shiv Chowk','400002','Maharashtra','Rajpath'),
(30,'Sambhajinagar','India','nagar chowk','400003','Maharashtra','Shivaji Statue'),

(31,'Solapur','India','ShaniwarWada','400003','Maharashtra','Fifth Avenue'),
(32,'Yawatmal','India','PowaiNaka','400004','Maharashtra','Rajpath'),
(33,'Mumbai','India','Worli','400004','Maharashtra','Dalal Street'),
(34,'Jalgaon','India','Shiv Chowk','400005','Maharashtra','Rajpath'),
(35,'Sambhajinagar','India','nagar chowk','400005','Maharashtra','Shivaji Statue');



INSERT INTO user VALUES 
(26,    'surajsetty@gmail.com'        ,   'customer1234',      'CUSTOMER'), 
(27,    'ehsaanganesh@gmail.com'      ,   'customer1234',      'CUSTOMER'), 
(28,    'afreendeshpande@gmail.com'   ,   'customer1234',      'CUSTOMER'), 
(29,    'aarifhayre@gmail.com'        ,   'customer1234',      'CUSTOMER'), 
(30,    'ritalata@gmail.com'          ,   'customer1234',      'CUSTOMER'), 
(31,    'suryaoza@gmail.com'          ,   'customer1234',      'CUSTOMER'), 
(32,    'aasthadua@gmail.com'         ,   'customer1234',      'CUSTOMER'), 
(33,    'abbashah@gmail.com'          ,   'customer1234',      'CUSTOMER'), 
(34,    'poonamwali@gmail.com'        ,   'customer1234',      'CUSTOMER'), 
(35,    'deepkhare@gmail.com'         ,   'customer1234',      'CUSTOMER');  
    

INSERT INTO customer VALUES 
(1,'surajsetty@gmail.com'      ,  'Suraj Setty'     ,   'customer1234',    '+919970586815',    'CUSTOMER',  10000  ,  26  ,  26  ),
(2,'ehsaanganesh@gmail.com'    ,  'Ehsaan Ganesh'   ,   'customer1234',    '+918007665352',    'CUSTOMER',  10000  ,  27  ,  27  ),
(3,'afreendeshpande@gmail.com' ,  'Afreen Deshpande',   'customer1234',    '+917487965748',    'CUSTOMER',  10000  ,  28  ,  28  ),
(4,'aarifhayre@gmail.com'      ,  'Aarif Hayre'     ,   'customer1234',    '+917894587130',    'CUSTOMER',  10000  ,  29  ,  29  ),
(5,'ritalata@gmail.com'        ,  'Rita Lata'       ,   'customer1234',    '+919157483690',    'CUSTOMER',  10000  ,  30  ,  30  ),
(6,'suryaoza@gmail.com'        ,  'Surya Oza'       ,   'customer1234',    '+919970586815',    'CUSTOMER',  10000  ,  31  ,  31  ),
(7,'aasthadua@gmail.com'       ,  'Aastha Dua'      ,   'customer1234',    '+918007665352',    'CUSTOMER',  10000  ,  32  ,  32  ),
(8,'abbashah@gmail.com'        ,  'Abbas Shah'      ,   'customer1234',    '+917487965748',    'CUSTOMER',  10000  ,  33  ,  33  ),
(9,'poonamwali@gmail.com'      ,  'Poonam Wali'     ,   'customer1234',    '+917894587130',    'CUSTOMER',  10000  ,  34  ,  34  ),
(10,'deepkhare@gmail.com'      ,  'Deep Khare'      ,   'customer1234',    '+919157483690',    'CUSTOMER',  10000  ,  35  ,  35  );



INSERT INTO user VALUES 
(36,    'admin@gmail.com'        ,   'admin',      'ADMIN'),
(37,    'admin'        ,   'admin',      'ADMIN');




         
      
       
       
       
         
            
          
             
        
      
      
       
      
        
      
